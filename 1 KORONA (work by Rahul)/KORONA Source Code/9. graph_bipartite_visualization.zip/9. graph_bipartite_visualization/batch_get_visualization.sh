#!/bin/bash

#./batch_get_visualization.sh <semEP folder with cluster folders in it> <entity1_description_file> <entity2_description_file>  <Name_of_entity1> <Name_of_entity2> <output_folder>

#./batch_get_visualization.sh ../output/author-clusters/semEP/95-percentile/ ../output/author-key-map.txt ../output/conf_description.txt Author Conference ../output/visualization/semEP/95-Percentile/

for cluster_file in $1* ; do
    #echo "$cluster_file/"
    filename=$(basename "$cluster_file" ".txt")
    #echo $filename
    #echo $(basename "${cluster_file%}")
    if [ "${filename/predictions}" != "$filename"  ];then
        echo ${cluster_file}
        continue
    fi
    mkdir -p $6$(basename "${cluster_file%}")/
    sh ./get_visualization.sh $cluster_file/ $2 $3 $(basename "${cluster_file%}") $4 $5 $6$(basename "${cluster_file%}")/
done


