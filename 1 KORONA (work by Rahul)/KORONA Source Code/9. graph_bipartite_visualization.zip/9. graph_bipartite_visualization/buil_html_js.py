#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from importlib import reload
import sys,os
reload(sys)

HTML_FILE = "base.html"
JS_FILE = "base.js"

M_JS_FILE = "JSONJSONJSON"
M_HTML_FILE = "JJJJSSSS"
              
ENTITY_LEFT ="EntityLeft"
ENTITY_RIGHT="EntityRight"

NODE_LEFT="LEFTNODES"
NODE_RIGHT="RIGHTNODES"

TITLE_STR = "nametitle"
HEADLINE_STR = "headertitle"


def replace_str(filename, l_replace):
    with open(filename, "r") as f:
        s = f.read()
        for (old, new) in l_replace:
            s = s.replace(old, new, 1)
    return s

def write_str(filename, str_out):
    with open(filename, "w") as f:
        f.write(str_out)

def main(*args):
    base_filename = args[0]
    e_left = args[1]
    e_right = args[2]
    print (args[3])
    temp_dir = args[3]
    
    destination_directory = os.path.dirname(temp_dir)
    
    print(args[3])
    json_new_file = base_filename + ".json"
    js_new_file = base_filename + ".js"
    html_new_file = base_filename + ".html"


    title_bar = os.path.basename(destination_directory) + " " + os.path.basename(os.path.dirname(os.path.dirname(destination_directory))) + " " + os.path.basename(os.path.dirname(destination_directory))

    l_replace = [(M_HTML_FILE, js_new_file), (ENTITY_LEFT, e_left), (ENTITY_RIGHT, e_right), (TITLE_STR, title_bar), (HEADLINE_STR, title_bar)]
    html_str = replace_str(HTML_FILE, l_replace)

    l_replace = [(M_JS_FILE, json_new_file), (NODE_LEFT, e_left), (NODE_RIGHT, e_right)]
    js_str = replace_str(JS_FILE, l_replace)

    write_str(html_new_file, html_str)
    write_str(js_new_file, js_str)

    print("HTML file "+html_new_file)
    print("JS file "+js_new_file)
    print("Done ")

if __name__ == '__main__':
    main(*sys.argv[1:])
