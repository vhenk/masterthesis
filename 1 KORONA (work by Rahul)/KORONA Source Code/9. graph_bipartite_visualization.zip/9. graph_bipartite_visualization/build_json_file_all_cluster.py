#!/usr/bin/env python3

import sys, os

###############################################
#
# Constants
#
###############################################

validated_str = {"Yes in Stitch and Kegg(correct)", "Yes in Stitch(correct)", "Yes in Kegg(correct)"}
not_validated_str = {"Not(wrong)"}
REL_INTERACTIVE = "Interactive"
CLUSTER = "Cluster"
INCREMENT = 50
INT_INCREMENT = 100
DRUG_TYPE = "RedWine"
TARGET_TYPE = "WhiteWine"
X_NODE_D = 1000
X_NODE_T = 1300
START_Y_POS = 900
START_SUID = 1
BAD_PRED = "bp"
VALID_PRED = "pd"
INTERACTION = "cc"

###############################################
#
# Loading all the data
#
###############################################

def get_key(d, t, p):
    return d+"-"+t+"-"+p

def load_predictions_validated(filename):
    predictions_validated = []
    with open(filename) as f:
        for line in f:
            line = line.rstrip()
            tok = line.split("\t")
            if not (tok[0] == CLUSTER):
                validated = VALID_PRED
                value = (tok[0], tok[1], validated, tok[2])
                predictions_validated.append(value)
                key = get_key(tok[0], tok[1], tok[2])
    predictions_validated.sort(key=lambda tup: tup[3], reverse=True)
    return predictions_validated

def load_all_predictions(filename):
    cluster_pred = {}
    interaction_predicted = {}
    key = "9999"
    with open(filename) as f:
        for line in f:
            line = line.rstrip()
            tok = line.split("\t")
            if tok[0] == CLUSTER:
                key = int(tok[1])
                if key not in cluster_pred:
                    cluster_pred[key] = []
                else:
                    print("Faltal repetead key "+key)
            else:
                if key in cluster_pred:
                     cluster_pred[key].append( (tok[0], tok[1], tok[2]) )
                     key2 = get_key(tok[0], tok[1], tok[2])
                     if key2 not in interaction_predicted:
                         interaction_predicted[key2] = key
                     else:
                         print("Fatal, interacction predicted repetead")
                         #sys.exit(1)
                else:
                    print("Fatal, key not found it. "+key)
                    sys.exit(1)
    return (cluster_pred, interaction_predicted)

def load_cluster_filenames(dirname):
    cluster_filenames = {}
    for filename in os.listdir(dirname):
        if filename.endswith(".txt"):
            tok = filename.split("-")
            key = int(tok[2])
            fpath = os.path.join(dirname, filename)
            cluster_filenames[key] = fpath 
        else:
            print("Fatal filename unknown "+filename)
    return cluster_filenames

def load_cluster_interactions(id_cluster, cluster_filenames):
    filename = cluster_filenames[id_cluster]
    ci = []
    d = set()
    t = set()
    with open(filename) as f:
        for line in f:
            line = line.rstrip()
            tok = line.split("\t")
            ci.append( (tok[0], tok[1]) )
            d.add(tok[0])
            t.add(tok[1])
    nd = len(d)
    nt = len(t)
    ne = len(ci)
    prob = (float) (ne / (nd*nt))
    ps = '{:.4f}'.format(prob)
    return (ci, ps)

def load_descriptions(filename):
    descrip = {}
    with open(filename) as f:
        for line in f:
            line = line.rstrip()
            tok = line.split("\t")
            k = tok[0]
            d = tok[1]
            if k not in descrip:
                descrip[k] = d
            else:
                print("Warning, repetead element "+k)
    return descrip

###############################################
#
# Building the json data
#
###############################################

def get_list_of_clusters(pred_validated, all_pred, inter_predicted, n_clusters):
    clusters_to_find = []
    current_cluster = -1
    for (d, t, validated, prob) in pred_validated:
        key = get_key(d, t, prob)
        cluster = inter_predicted[key]
        if cluster != current_cluster:
            assert(cluster not in clusters_to_find)
            clusters_to_find.append(cluster)
            if len(clusters_to_find) == n_clusters:
                return clusters_to_find
            current_cluster = cluster
    return clusters_to_find

def init_json_file():
    init_str =  "{\n\"format_version\" : \"1.0\",\n\"generated_by\" : \"cytoscape-3.2.0\",\n\"target_cytoscapejs_version\" : \"~2.1\",\n\"data\" : {\n\"selected\" : true,\n\"__Annotations\" : [ ],\n\"shared_name\" : \"WineCheeseNetwork\",\n\"SUID\" : 52,\n\"name\" : \"WineCheeseNetwork\"\n},\n\"elements\" : {\n\"nodes\" : ["
    return init_str

def end_node_json():
    return "\n],\n"

def start_edges_json():
    return "\"edges\" : [\n" 

def end_edges_json():
    return "]\n"

def end_json_file():
    return "}\n}"

def get_node_json(node_id, node_descp, posx, posy, suid, node_type):
    nstart = "{\n"
    data = "\"data\" : {\n"
    idn = "\"id\":\""+node_id+"\",\n"
    sel = "\"selected\":false,\n"
    alias = "\"cytoscape_alias_list\":[\""+node_descp+"\"],\n"
    cname = "\"canonicalName\": \""+node_descp+"\",\n"
    nsuid = "\"SUID\":"+str(suid)+",\n"
    ntype = "\"NodeType\": \""+node_type+"\",\n"
    nname = "\"name\": \""+node_descp+"\",\n"
    sname = "\"shared_name\": \""+node_descp+"\"\n"
    enddata = "},\n" 
    nposition = "\"position\" : {\n"
    nx = "\t\"x\" : "+str(posx)+",\n"
    ny = "\t\"y\" : "+str(posy)+"\n"
    endpos = "},\n"
    sel2 = "\"selected\":false\n"
    nend = "}\n"
    node_str = nstart+data+idn+sel+alias+cname+nsuid+ntype+nname+sname+enddata+nposition+nx+ny+endpos+sel2+nend
    return node_str

def compute_node_increments(id_cluster, cluster_filenames):
    filename = cluster_filenames[id_cluster]
    #print(filename)
    ci = []
    d = set()
    t = set()
    with open(filename) as f:
        for line in f:
            line = line.rstrip()
            tok = line.split("\t")
            d.add(tok[0])
            t.add(tok[1])
    nd = len(d)
    nt = len(t)
    if nd == 1:
        nd = nd + 1
    if nt == 1:
        nt = nt + 1
        
    if nd > nt:
        drug_incr = INCREMENT
        space_used = (nd-1)*INCREMENT
        if nt == 0:
            increment2 = 0
        else:
            increment2 = space_used/(nt-1)
        target_incr = increment2
    else:
        target_incr = INCREMENT
        space_used = (nt-1)*INCREMENT
        if (nd == 0):
            increment2 = 0
        else:
            increment2 = space_used /(nd-1)
        drug_incr = increment2
    return (drug_incr, target_incr)

def str_node_cluster(id_cluster, cluster_filenames, drug_descrp, target_descrp, y_node_d, y_node_t, suid_node_cont):
    drugs = set()
    targets = set()
    cluster_str = ""
    (d_incr, t_incr) = compute_node_increments(id_cluster, cluster_filenames)
    y_node_d = y_node_d + INT_INCREMENT
    y_node_t = y_node_t + INT_INCREMENT

    y_node_d = max(y_node_d, y_node_t) 
    y_node_t = max(y_node_d, y_node_t) 

    (li, prob) = load_cluster_interactions(id_cluster, cluster_filenames)
    first = True
    for (d, t) in li:
        dd = drug_descrp[d]
        td = target_descrp[t]
        if first:
            cluster_str += get_node_json(d+str(id_cluster), dd, X_NODE_D, y_node_d, suid_node_cont, DRUG_TYPE) 
            suid_node_cont = suid_node_cont + 1
            y_node_d = y_node_d + d_incr
            drugs.add(d)
            
            cluster_str += " ,\n"
            
            cluster_str += get_node_json(t+str(id_cluster), td, X_NODE_T, y_node_t, suid_node_cont, TARGET_TYPE)
            suid_node_cont = suid_node_cont + 1
            y_node_t = y_node_t + t_incr
            targets.add(t)
            first = False
        else:
            if d not in drugs:
                cluster_str += " ,\n"
                cluster_str += get_node_json(d+str(id_cluster), dd, X_NODE_D, y_node_d, suid_node_cont, DRUG_TYPE)
                suid_node_cont = suid_node_cont + 1
                y_node_d = y_node_d + d_incr
                drugs.add(d)
            if t not in targets:
                cluster_str += " ,\n"
                cluster_str += get_node_json(t+str(id_cluster), td, X_NODE_T, y_node_t, suid_node_cont, TARGET_TYPE)
                suid_node_cont = suid_node_cont + 1
                y_node_t = y_node_t + t_incr
                targets.add(t)
    y_node_d -= d_incr
    y_node_t -= t_incr
    return cluster_str, y_node_d, y_node_t, suid_node_cont

def str_all_clusters(cluster_filenames, drug_descrp, target_descrp):
    str_nodes = init_json_file()
    suid_n = START_SUID
    y_n_d = START_Y_POS
    y_n_t = START_Y_POS
    clusters_id = list(cluster_filenames.keys())
    sorted(clusters_id)
    for c in clusters_id[:-1] :
        (cluster_str, y_d_end, y_t_end, scont) = str_node_cluster(c, cluster_filenames, drug_descrp, target_descrp, y_n_d, y_n_t, suid_n)
        str_nodes += cluster_str + ","
        y_n_d  = y_d_end
        y_n_t = y_t_end
        suid_n = scont + 1
    (cluster_str, y_d_end, y_t_end, scont) = str_node_cluster(clusters_id[-1], cluster_filenames, drug_descrp, target_descrp, y_n_d, y_n_t, suid_n+1)
    str_nodes += cluster_str + end_node_json()
    return str_nodes

def str_edge(e_id, source, target, suid_e, edge_type):
    s_initial = "{\"data\" : {\n"
    s_id = "\"id\" : \""+e_id+"\",\n"
    s_source = "\"source\" : \""+source+"\",\n"
    s_target = "\"target\" : \""+target+"\",\n"
    s_selectet = "\"selected\" : false,\n"
    s_cn = "\"canonicalName\" : \""+source+" ("+edge_type+") "+target+"\",\n"
    s_suid = "\"SUID\" : "+str(suid_e)+",\n"
    s_n = "\"name\" : \""+source+" ("+edge_type+") "+target+"\",\n"
    s_int = "\"interaction\" : \""+edge_type+"\",\n"
    s_sint = "\"shared_interaction\" : \""+edge_type+"\",\n"
    s_sn = "\"shared_name\" : \""+source+" ("+edge_type+") "+target+"\"\n"
    s_end = "},\n\"selected\" : false\n}\n"
    return s_initial+s_id+s_source+s_target+s_selectet+s_cn+s_suid+s_n+s_int+s_sint+s_sn+s_end

def str_interaction(cluster_filenames, d_descrip, t_descrip):
    c_prob = {}
    id_edges = 1
    str_edges = ""
    lclusters = list(cluster_filenames.keys())
    sorted(lclusters)
    for c in lclusters:
        (c_inter, prob) = load_cluster_interactions(c, cluster_filenames)
        c_prob[c] = prob
        for (d, t) in c_inter:
            id_d = d+str(c)
            id_t = t+str(c)
            str_edges += str_edge(str(id_edges), id_d, id_t, id_edges, INTERACTION)
            str_edges +=",\n"
            id_edges += 1
        
    str_edges = str_edges[:-2]+"\n"
    return str_edges

###############################################
#
#                  Main
#
###############################################

def main(*args):
    cf = load_cluster_filenames(args[0])
    drug_descriptions = load_descriptions(args[1])
    target_descriptions = load_descriptions(args[2])
    str_w_nodes = str_all_clusters(cf, drug_descriptions, target_descriptions)
    str_list_edges = str_interaction(cf, drug_descriptions, target_descriptions)    
    json_data = str_w_nodes + start_edges_json() + str_list_edges + end_edges_json() + end_json_file()
    filename_output = args[3]
    with open(filename_output, "w") as f:
            f.write(json_data)
    print("\nDone, output json file "+filename_output)
    
if __name__ == '__main__':
    main(*sys.argv[1:])
