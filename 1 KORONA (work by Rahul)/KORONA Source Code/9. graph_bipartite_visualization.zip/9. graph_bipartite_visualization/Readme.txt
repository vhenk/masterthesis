About
=====

Visualization of semEP clustering

Version
=======
0.1

Usage
======

Get into the folder "graph_bipartite_visualization" and execute the following command:

./get_visualization.sh <semEP_clustering_folder> <entity1_description_file> <entity2_description_file> <name_of_output_file> <Name_of_entity1> <Name_of_entity2> <output_folder>

Running an example
==================

Example 1: Tiny set of clusters of semEP on author-conference dataset, run:

>./get_visualization.sh author_conf/Auth-Conf_graph-0.3333-0.1586-Clusters_Tiny/ author_conf/author_description.txt author_conf/conf_description.txt clusters_auth_conf Author Conference graph_author_confe_tiny/

The results are in the folder "graph_author_confe_tiny". To see the clusters, open the
file "graph_author_confe_tiny/clusters_auth_conf.html" with Firefox browser 


./get_visualization.sh ../output/semEP-clusters/95-percentile/ ../output/author-key-map.txt ../output/conf_description.txt semEP-clusters Author Conference ../output/


Example 2: Partial set of clusters of semEP on author-conference dataset, run:

>./get_visualization.sh author_conf/Auth-Conf_graph-0.3333-0.1586-Clusters_Parcial/ author_conf/author_description.txt author_conf/conf_description.txt clusters_auth_conf Author Conference graph_author_confe_partial/

The results are in the folder "graph_author_confe_tiny". To see the clusters, open the
file "graph_author_confe_partial/clusters_auth_conf.html" with Firefox browser 

Contact
========

Guillermo Palma (palma@l3s.de)
