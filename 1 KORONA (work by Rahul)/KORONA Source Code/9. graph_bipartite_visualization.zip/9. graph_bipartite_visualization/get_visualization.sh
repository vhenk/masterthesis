#!/bin/bash
echo "Building the json file"
./build_json_file_all_cluster.py $1 $2 $3 $4".json"
echo "Building the js and html files"
./buil_html_js.py $4 $5 $6 $7
echo "Copying data to the directory "$7
cp -R bluebird.min.js bootstrap-3.3.7-dist bootstrap.min.js cytoscape.min.js cytoscape-qtip.js fastclick.min.js font-awesome-4.7.0 handlebars.min.js dblp.ico jquery.min.js jquery.qtip.min.css jquery.qtip.min.js lodash.min.js style.css style.cycss typeahead.bundle.js $7

mv $4".json" $4".js" $4".html" $7
