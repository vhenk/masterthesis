var VRecA5cps98 = {"id":"A5","name":"Emanuele Della Valle","recommendations":[]};
var VRecA24cps98 = {"id":"A24","name":"Axel Polleres","recommendations":[]};
var VRecA88cps98 = {"id":"A88","name":"Maria-Esther Vidal","recommendations":[]};
var VRecA136cps98 = {"id":"A136","name":"Sören Auer","recommendations":[]};
var VRecA138cps98 = {"id":"A138","name":"Jens Lehmann","recommendations":[]};
var VRecA295cps98 = {"id":"A295","name":"Olaf Hartig","recommendations":[]};
var VRecA551cps98 = {"id":"A551","name":"Abraham Bernstein","recommendations":[]};