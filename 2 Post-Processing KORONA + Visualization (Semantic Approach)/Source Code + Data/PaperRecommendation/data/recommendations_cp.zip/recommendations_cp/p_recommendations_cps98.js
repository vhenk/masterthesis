var PRecA5cps98 = {"id":"A5","numrecommendations":0,"papers":[]};
var PRecA24cps98 = {"id":"A24","numrecommendations":0,"papers":[]};
var PRecA88cps98 = {"id":"A88","numrecommendations":0,"papers":[]};
var PRecA136cps98 = {"id":"A136","numrecommendations":0,"papers":[]};
var PRecA138cps98 = {"id":"A138","numrecommendations":0,"papers":[]};
var PRecA295cps98 = {"id":"A295","numrecommendations":0,"papers":[]};
var PRecA551cps98 = {"id":"A551","numrecommendations":0,"papers":[]};