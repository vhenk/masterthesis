var A202s98 = {"id":"A202","clusters":[]};
var A657s98 = {"id":"A657","clusters":[]};
var A129s98 = {"id":"A129","clusters":[]};
var A26s98 = {"id":"A26","clusters":[]};
var A37s98 = {"id":"A37","clusters":[]};
var A130s98 = {"id":"A130","clusters":[]};
var A838s98 = {"id":"A838","clusters":[]};
var A327s98 = {"id":"A327","clusters":[]};