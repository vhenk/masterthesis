var PRecA327s95 = {"id":"A327","numrecommendations":0,"papers":[]};
var PRecA26s95 = {"id":"A26","numrecommendations":0,"papers":[]};
var PRecA37s95 = {"id":"A37","numrecommendations":0,"papers":[]};
var PRecA130s95 = {"id":"A130","numrecommendations":0,"papers":[]};
var PRecA129s95 = {"id":"A129","numrecommendations":0,"papers":[]};
var PRecA202s95 = {"id":"A202","numrecommendations":0,"papers":[]};
var PRecA657s95 = {"id":"A657","numrecommendations":0,"papers":[]};
var PRecA838s95 = {"id":"A838","numrecommendations":0,"papers":[]};