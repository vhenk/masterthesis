var VRecA327cps98 = {"id":"A327","name":"Emanuele Della Valle","recommendations":[]};
var VRecA26cps98 = {"id":"A26","name":"Axel Polleres","recommendations":[]};
var VRecA37cps98 = {"id":"A37","name":"Maria-Esther Vidal","recommendations":[]};
var VRecA130cps98 = {"id":"A130","name":"Sören Auer","recommendations":[]};
var VRecA129cps98 = {"id":"A129","name":"Jens Lehmann","recommendations":[]};
var VRecA202cps98 = {"id":"A202","name":"Elena Paslaru Bontas Simperl","recommendations":[]};
var VRecA657cps98 = {"id":"A657","name":"Olaf Hartig","recommendations":[]};
var VRecA838cps98 = {"id":"A838","name":"Abraham Bernstein","recommendations":[]};