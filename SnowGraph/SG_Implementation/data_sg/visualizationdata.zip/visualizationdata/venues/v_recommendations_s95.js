var VRecA327s95 = {"id":"A327","name":"Emanuele Della Valle","recommendations":[]};
var VRecA26s95 = {"id":"A26","name":"Axel Polleres","recommendations":[]};
var VRecA37s95 = {"id":"A37","name":"Maria-Esther Vidal","recommendations":[]};
var VRecA130s95 = {"id":"A130","name":"Sören Auer","recommendations":[]};
var VRecA129s95 = {"id":"A129","name":"Jens Lehmann","recommendations":[]};
var VRecA202s95 = {"id":"A202","name":"Elena Paslaru Bontas Simperl","recommendations":[]};
var VRecA657s95 = {"id":"A657","name":"Olaf Hartig","recommendations":[]};
var VRecA838s95 = {"id":"A838","name":"Abraham Bernstein","recommendations":[]};