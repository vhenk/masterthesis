var VRecA327cps95 = {"id":"A327","name":"Emanuele Della Valle","recommendations":[]};
var VRecA26cps95 = {"id":"A26","name":"Axel Polleres","recommendations":[]};
var VRecA37cps95 = {"id":"A37","name":"Maria-Esther Vidal","recommendations":[]};
var VRecA130cps95 = {"id":"A130","name":"Sören Auer","recommendations":[]};
var VRecA129cps95 = {"id":"A129","name":"Jens Lehmann","recommendations":[]};
var VRecA202cps95 = {"id":"A202","name":"Elena Paslaru Bontas Simperl","recommendations":[]};
var VRecA657cps95 = {"id":"A657","name":"Olaf Hartig","recommendations":[]};
var VRecA838cps95 = {"id":"A838","name":"Abraham Bernstein","recommendations":[]};