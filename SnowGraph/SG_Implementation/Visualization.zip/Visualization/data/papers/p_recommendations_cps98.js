var PRecA327cps98 = {"id":"A327","numrecommendations":0,"papers":[]};
var PRecA26cps98 = {"id":"A26","numrecommendations":0,"papers":[]};
var PRecA37cps98 = {"id":"A37","numrecommendations":0,"papers":[]};
var PRecA130cps98 = {"id":"A130","numrecommendations":0,"papers":[]};
var PRecA129cps98 = {"id":"A129","numrecommendations":0,"papers":[]};
var PRecA202cps98 = {"id":"A202","numrecommendations":0,"papers":[]};
var PRecA657cps98 = {"id":"A657","numrecommendations":0,"papers":[]};
var PRecA838cps98 = {"id":"A838","numrecommendations":0,"papers":[]};