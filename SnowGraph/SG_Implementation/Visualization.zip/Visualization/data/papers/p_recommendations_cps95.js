var PRecA327cps95 = {"id":"A327","numrecommendations":0,"papers":[]};
var PRecA26cps95 = {"id":"A26","numrecommendations":0,"papers":[]};
var PRecA37cps95 = {"id":"A37","numrecommendations":0,"papers":[]};
var PRecA130cps95 = {"id":"A130","numrecommendations":0,"papers":[]};
var PRecA129cps95 = {"id":"A129","numrecommendations":0,"papers":[]};
var PRecA202cps95 = {"id":"A202","numrecommendations":0,"papers":[]};
var PRecA657cps95 = {"id":"A657","numrecommendations":0,"papers":[]};
var PRecA838cps95 = {"id":"A838","numrecommendations":0,"papers":[]};