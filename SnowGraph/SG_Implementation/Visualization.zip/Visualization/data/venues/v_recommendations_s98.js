var VRecA327s98 = {"id":"A327","name":"Emanuele Della Valle","recommendations":[]};
var VRecA26s98 = {"id":"A26","name":"Axel Polleres","recommendations":[]};
var VRecA37s98 = {"id":"A37","name":"Maria-Esther Vidal","recommendations":[]};
var VRecA130s98 = {"id":"A130","name":"Sören Auer","recommendations":[]};
var VRecA129s98 = {"id":"A129","name":"Jens Lehmann","recommendations":[]};
var VRecA202s98 = {"id":"A202","name":"Elena Paslaru Bontas Simperl","recommendations":[]};
var VRecA657s98 = {"id":"A657","name":"Olaf Hartig","recommendations":[]};
var VRecA838s95 = {"id":"A838","name":"Abraham Bernstein","recommendations":[]};